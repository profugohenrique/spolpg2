/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ifsp.Exemplo2.controller;

import br.ifsp.Exemplo2.model.Usuario;
import br.ifsp.Exemplo2.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {
    
    @Autowired
    private UsuarioService usuarioService;
    
    // Listar todos os usuários
    @GetMapping
    public String listarUsuarios(Model model) {
        List<Usuario> usuarios = usuarioService.listarTodos();
        model.addAttribute("usuarios", usuarios);
        return "usuarios/listar";
    }
    
    // Formulário de novo usuário
    @GetMapping("/novo")
    public String mostrarFormularioNovo(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "usuarios/formulario";
    }
    
    // Formulário de edição
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        Optional<Usuario> usuario = usuarioService.buscarPorId(id);
        if (usuario.isPresent()) {
            model.addAttribute("usuario", usuario.get());
            return "usuarios/formulario";
        }
        return "redirect:/usuarios";
    }
    
    // Salvar usuário (create/update)
    @PostMapping("/salvar")
    public String salvarUsuario(@Valid @ModelAttribute Usuario usuario, 
                               BindingResult result, Model model) {
        
        // Verificar se email já existe (para novo usuário)
        if (usuario.getId() == null && usuarioService.emailExiste(usuario.getEmail())) {
            result.rejectValue("email", "error.usuario", "Email já está em uso");
        }
        
        // Verificar se email existe para outro usuário (para edição)
        if (usuario.getId() != null && 
            usuarioService.emailExisteParaOutroUsuario(usuario.getEmail(), usuario.getId())) {
            result.rejectValue("email", "error.usuario", "Email já está em uso por outro usuário");
        }
        
        if (result.hasErrors()) {
            return "usuarios/formulario";
        }
        
        usuarioService.salvar(usuario);
        return "redirect:/usuarios";
    }
    
    // Deletar usuário
    @GetMapping("/deletar/{id}")
    public String deletarUsuario(@PathVariable Long id) {
        usuarioService.deletar(id);
        return "redirect:/usuarios";
    }
    
    // Buscar por nome
    @GetMapping("/buscar")
    public String buscarPorNome(@RequestParam String nome, Model model) {
        List<Usuario> usuarios = usuarioService.buscarPorNome(nome);
        model.addAttribute("usuarios", usuarios);
        model.addAttribute("termoBusca", nome);
        return "usuarios/listar";
    }
}