package br.ifsp.Exemplo2.repository;

import br.ifsp.Exemplo2.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Repositório para operações de persistência da entidade Usuario.
 * Fornece métodos personalizados além dos CRUD padrão do JpaRepository.
 */
@Repository
@Transactional(readOnly = true)
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    
    /**
     * Busca usuários cujo nome contenha o texto informado (case-insensitive).
     *
     * @param nome Texto a ser buscado no nome
     * @return Lista de usuários encontrados
     */
    List<Usuario> findByNomeContainingIgnoreCase(String nome);
    
    /**
     * Busca usuários cujo nome comece com o texto informado (case-insensitive).
     *
     * @param nome Prefixo do nome
     * @return Lista de usuários encontrados
     */
    List<Usuario> findByNomeStartingWithIgnoreCase(String nome);
    
    /**
     * Verifica se existe um usuário com o email informado.
     *
     * @param email Email a ser verificado
     * @return true se o email existir, false caso contrário
     */
    boolean existsByEmail(String email);
    
    /**
     * Busca um usuário pelo email exato (case-insensitive).
     *
     * @param email Email do usuário
     * @return Optional contendo o usuário encontrado ou vazio
     */
    Optional<Usuario> findByEmailIgnoreCase(String email);
    
    /**
     * Retorna todos os usuários ordenados alfabeticamente por nome.
     *
     * @return Lista de usuários ordenados por nome
     */
    List<Usuario> findAllByOrderByNomeAsc();
    
    /**
     * Retorna todos os usuários ordenados por data de criação (mais recentes primeiro).
     *
     * @return Lista de usuários ordenados por data de criação
     */
    List<Usuario> findAllByOrderByDataCriacaoDesc();
    
    /**
     * Busca usuários por parte do email (case-insensitive).
     *
     * @param email Parte do email a ser buscado
     * @return Lista de usuários encontrados
     */
    List<Usuario> findByEmailContainingIgnoreCase(String email);
    
    /**
     * Conta quantos usuários possuem o email informado.
     *
     * @param email Email a ser verificado
     * @return Número de usuários com o email
     */
    long countByEmail(String email);
    
    /**
     * Busca usuários ativos ordenados por nome.
     *
     * @return Lista de usuários ativos
     */
    List<Usuario> findByAtivoTrueOrderByNomeAsc();
    
    /**
     * Busca usuários por nome usando consulta personalizada com LIKE.
     *
     * @param nome Termo de busca para o nome
     * @return Lista de usuários encontrados
     */
    @Query("SELECT u FROM Usuario u WHERE LOWER(u.nome) LIKE LOWER(CONCAT('%', :nome, '%'))")
    List<Usuario> buscarPorNomePersonalizado(@Param("nome") String nome);
    
    /**
     * Busca usuários por email exato.
     *
     * @param email Email exato a ser buscado
     * @return Optional com o usuário encontrado
     */
    @Query("SELECT u FROM Usuario u WHERE u.email = :email")
    Optional<Usuario> buscarPorEmailExato(@Param("email") String email);
    
    /**
     * Busca os primeiros N usuários ordenados por nome.
     *
     * @param limit Número máximo de usuários a retornar
     * @return Lista de usuários
     */
    @Query("SELECT u FROM Usuario u ORDER BY u.nome ASC")
    List<Usuario> findTopNOrderByNomeAsc(@Param("limit") int limit);
    
    /**
     * Verifica se existe outro usuário com o mesmo email excluindo um ID específico.
     * Útil para validações durante atualizações.
     *
     * @param email Email a verificar
     * @param id ID do usuário a excluir da verificação
     * @return true se existir outro usuário com o email, false caso contrário
     */
    @Query("SELECT CASE WHEN COUNT(u) > 0 THEN true ELSE false END " +
           "FROM Usuario u WHERE u.email = :email AND u.id <> :id")
    boolean existsByEmailAndIdNot(@Param("email") String email, @Param("id") Long id);
    
    /**
     * Busca usuários por intervalo de IDs.
     *
     * @param idInicial ID inicial do intervalo
     * @param idFinal ID final do intervalo
     * @return Lista de usuários no intervalo de IDs
     */
    List<Usuario> findByIdBetween(Long idInicial, Long idFinal);
    
    /**
     * Deleta usuários pelo email.
     *
     * @param email Email dos usuários a serem deletados
     * @return Número de registros deletados
     */
    @Transactional
    long deleteByEmail(String email);
}