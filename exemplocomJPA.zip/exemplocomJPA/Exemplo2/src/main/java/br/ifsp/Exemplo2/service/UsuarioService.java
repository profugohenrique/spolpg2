package br.ifsp.Exemplo2.service;

import br.ifsp.Exemplo2.model.Usuario;
import br.ifsp.Exemplo2.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Serviço para operações relacionadas a usuários.
 * Inclui validações de negócio e operações CRUD.
 */
@Service
@Transactional
public class UsuarioService {
    
    private final UsuarioRepository usuarioRepository;
    
    @Autowired
    public UsuarioService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }
    
    /**
     * Retorna todos os usuários ordenados por nome.
     */
    @Transactional(readOnly = true)
    public List<Usuario> listarTodos() {
        return usuarioRepository.findAll().stream()
                .sorted((u1, u2) -> u1.getNome().compareToIgnoreCase(u2.getNome()))
                .collect(Collectors.toList());
    }
    
    /**
     * Busca um usuário pelo ID.
     */
    @Transactional(readOnly = true)
    public Optional<Usuario> buscarPorId(Long id) {
        if (id == null || id <= 0) {
            throw new IllegalArgumentException("ID do usuário inválido: " + id);
        }
        return usuarioRepository.findById(id);
    }
    
    /**
     * Salva um usuário, validando se o email já existe.
     */
    public Usuario salvar(Usuario usuario) {
        validarUsuario(usuario);
        validarEmailUnico(usuario);
        return usuarioRepository.save(usuario);
    }
    
    /**
     * Atualiza um usuário existente, validando se o email já existe para outro usuário.
     */
    public Usuario atualizar(Long id, Usuario usuario) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuário não encontrado com ID: " + id);
        }
        
        validarUsuario(usuario);
        validarEmailUnicoParaAtualizacao(id, usuario.getEmail());
        
        usuario.setId(id);
        return usuarioRepository.save(usuario);
    }
    
    /**
     * Deleta um usuário pelo ID.
     */
    public void deletar(Long id) {
        if (!usuarioRepository.existsById(id)) {
            throw new IllegalArgumentException("Usuário não encontrado com ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }
    
    /**
     * Busca usuários por nome (busca parcial case-insensitive).
     */
    @Transactional(readOnly = true)
    public List<Usuario> buscarPorNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Nome não pode ser vazio");
        }
        return usuarioRepository.findByNomeContainingIgnoreCase(nome.trim());
    }
    
    /**
     * Verifica se um email já existe no sistema.
     */
    @Transactional(readOnly = true)
    public boolean emailExiste(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email não pode ser vazio");
        }
        String emailNormalizado = email.trim().toLowerCase();
        
        // Implementação alternativa se existsByEmail não existir
        return buscarPorEmail(emailNormalizado).isPresent();
    }
    
    /**
     * Verifica se um email existe para outro usuário (útil para atualizações).
     */
    @Transactional(readOnly = true)
    public boolean emailExisteParaOutroUsuario(String email, Long idExcluir) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email não pode ser vazio");
        }
        if (idExcluir == null || idExcluir <= 0) {
            throw new IllegalArgumentException("ID inválido para exclusão: " + idExcluir);
        }
        
        String emailNormalizado = email.trim().toLowerCase();
        
        // Busca manualmente por email e verifica se pertence a outro usuário
        return usuarioRepository.findAll().stream()
                .filter(usuario -> usuario.getEmail().equalsIgnoreCase(emailNormalizado))
                .findFirst()
                .map(usuario -> !usuario.getId().equals(idExcluir))
                .orElse(false);
    }
    
    /**
     * Validações básicas do objeto Usuario.
     */
    private void validarUsuario(Usuario usuario) {
        if (usuario == null) {
            throw new IllegalArgumentException("Usuário não pode ser nulo");
        }
        if (usuario.getNome() == null || usuario.getNome().trim().isEmpty()) {
            throw new IllegalArgumentException("Nome do usuário não pode ser vazio");
        }
        if (usuario.getEmail() == null || usuario.getEmail().trim().isEmpty()) {
            throw new IllegalArgumentException("Email do usuário não pode ser vazio");
        }
        if (!usuario.getEmail().contains("@")) {
            throw new IllegalArgumentException("Email inválido");
        }
    }
    
    /**
     * Valida se o email é único para criação de novo usuário.
     */
    private void validarEmailUnico(Usuario usuario) {
        String email = usuario.getEmail().trim().toLowerCase();
        if (emailExiste(email)) {
            throw new IllegalStateException("Já existe um usuário com o email: " + email);
        }
    }
    
    /**
     * Valida se o email é único para atualização de usuário existente.
     */
    private void validarEmailUnicoParaAtualizacao(Long id, String email) {
        String emailNormalizado = email.trim().toLowerCase();
        
        // Busca manualmente usuários com o mesmo email
        usuarioRepository.findAll().stream()
                .filter(usuario -> usuario.getEmail().equalsIgnoreCase(emailNormalizado))
                .findFirst()
                .ifPresent(usuarioExistente -> {
                    if (!usuarioExistente.getId().equals(id)) {
                        throw new IllegalStateException("Já existe outro usuário com o email: " + emailNormalizado);
                    }
                });
    }
    
    /**
     * Busca usuário por email.
     */
    @Transactional(readOnly = true)
    public Optional<Usuario> buscarPorEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            throw new IllegalArgumentException("Email não pode ser vazio");
        }
        
        String emailNormalizado = email.trim().toLowerCase();
        
        // Implementação alternativa se findByEmail não existir no repositório
        return usuarioRepository.findAll().stream()
                .filter(usuario -> usuario.getEmail().equalsIgnoreCase(emailNormalizado))
                .findFirst();
    }
    
    /**
     * Conta o total de usuários no sistema.
     */
    @Transactional(readOnly = true)
    public long contarTotal() {
        return usuarioRepository.count();
    }
}