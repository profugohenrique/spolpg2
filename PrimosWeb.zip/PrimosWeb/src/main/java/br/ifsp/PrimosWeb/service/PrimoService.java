/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ifsp.PrimosWeb.service;

import br.ifsp.PrimosWeb.Model.Primo;
import org.springframework.stereotype.Service;

/**
 *
 * @author ugohenrique
 */
@Service 
public class PrimoService {
    Primo primo;

    public PrimoService() {
        this.primo = new Primo();
    }

    public String getPrimos(){
      String lista = "";
        for (int i = 2; i <= 1000; i++) {
            if (primo.isPrimo(i)){
                lista += String.valueOf(i) +",";
            }
        }
        return lista;
       }
    
}
