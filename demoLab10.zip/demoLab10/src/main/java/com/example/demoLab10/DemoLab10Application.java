package com.example.demoLab10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoLab10Application {

	public static void main(String[] args) {
		SpringApplication.run(DemoLab10Application.class, args);
	}

}
