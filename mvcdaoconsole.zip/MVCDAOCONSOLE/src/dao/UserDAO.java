package dao;

import model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private static final String URL = "jdbc:mysql://localhost:3306/eng3";
    private static final String URLSQLITE = "jdbc:sqlite://home/ugohenrique/Downloads/sqlite-tools-linux-x64-3500400/eng3.db";
    private static final String USER = "eng3";
    private static final String PASSWORD = "Password123!@#";
    
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URLSQLITE);
    }
    
    // CREATE - Adicionar usuário
    public boolean addUser(User user) {
        String sql = "INSERT INTO users (usuario, senha) VALUES (?, ?)";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, user.getUsuario());
            pstmt.setString(2, user.getSenha());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Erro ao adicionar usuário: " + e.getMessage());
            return false;
        }
    }
    
    // READ - Buscar todos os usuários
    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        String sql = "SELECT usuario, senha FROM users";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                users.add(new User(
                    rs.getString("usuario"),
                    rs.getString("senha")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Erro ao buscar usuários: " + e.getMessage());
        }
        
        return users;
    }
    
    // READ - Buscar usuário por nome (VULNERÁVEL)
    public List<User> getUserVulnerable(String usuario) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT usuario, senha FROM users WHERE usuario = '" + usuario + "'";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                users.add(new User(
                    rs.getString("usuario"),
                    rs.getString("senha")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Erro ao buscar usuário: " + e.getMessage());
        }
        
        return users;
    }
    
    // READ - Buscar usuário por nome (SEGURO)
    public List<User> getUserSecure(String usuario) {
        List<User> users = new ArrayList<>();
        String sql = "SELECT usuario, senha FROM users WHERE usuario = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, usuario);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                users.add(new User(
                    rs.getString("usuario"),
                    rs.getString("senha")
                ));
            }
            
        } catch (SQLException e) {
            System.out.println("Erro ao buscar usuário: " + e.getMessage());
        }
        
        return users;
    }
    
    // UPDATE - Atualizar senha
    public boolean updateUser(User user) {
        String sql = "UPDATE users SET senha = ? WHERE usuario = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, user.getSenha());
            pstmt.setString(2, user.getUsuario());
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Erro ao atualizar usuário: " + e.getMessage());
            return false;
        }
    }
    
    // DELETE - Remover usuário
    public boolean deleteUser(String usuario) {
        String sql = "DELETE FROM users WHERE usuario = ?";
        
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, usuario);
            
            return pstmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.out.println("Erro ao deletar usuário: " + e.getMessage());
            return false;
        }
    }
}