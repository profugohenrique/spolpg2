package controller;

import service.UserService;
import model.User;
import java.util.List;
import java.util.Scanner;

public class UserController {
    private UserService userService;
    private Scanner scanner;
    
    public UserController() {
        this.userService = new UserService();
        this.scanner = new Scanner(System.in);
    }
    
    public void iniciar() {
        int opcao;
        
        do {
            exibirMenu();
            opcao = scanner.nextInt();
            scanner.nextLine(); // Limpar buffer
            
            switch (opcao) {
                case 1: adicionarUsuario(); break;
                case 2: listarUsuarios(); break;
                case 3: buscarUsuarioVulneravel(); break;
                case 4: buscarUsuarioSeguro(); break;
                case 5: atualizarUsuario(); break;
                case 6: deletarUsuario(); break;
                case 7: testarSQLInjection(); break;
                case 0: System.out.println("Saindo..."); break;
                default: System.out.println("Opção inválida!");
            }
            
        } while (opcao != 0);
        
        scanner.close();
    }
    
    private void exibirMenu() {
        System.out.println("\n=== SISTEMA DE USUÁRIOS ===");
        System.out.println("1. Adicionar usuário");
        System.out.println("2. Listar todos os usuários");
        System.out.println("3. Buscar usuário (VULNERÁVEL)");
        System.out.println("4. Buscar usuário (SEGURO)");
        System.out.println("5. Atualizar senha");
        System.out.println("6. Deletar usuário");
        System.out.println("7. Testar SQL Injection");
        System.out.println("0. Sair");
        System.out.print("Escolha: ");
    }
    
    private void adicionarUsuario() {
        System.out.print("Usuário: ");
        String usuario = scanner.nextLine();
        System.out.print("Senha: ");
        String senha = scanner.nextLine();
        
        User user = new User(usuario, senha);
        
        if (userService.addUser(user)) {
            System.out.println("✅ Usuário adicionado com sucesso!");
        } else {
            System.out.println("❌ Erro ao adicionar usuário!");
        }
    }
    
    private void listarUsuarios() {
        List<User> users = userService.getAllUsers();
        
        if (users.isEmpty()) {
            System.out.println("Nenhum usuário encontrado!");
        } else {
            System.out.println("\n=== LISTA DE USUÁRIOS ===");
            for (User user : users) {
                System.out.println("Usuário: " + user.getUsuario() + 
                                 " | Senha: " + user.getSenha());
            }
        }
    }
    
    private void buscarUsuarioVulneravel() {
        System.out.print("Digite o usuário: ");
        String usuario = scanner.nextLine();
        
        List<User> users = userService.getUserVulnerable(usuario);
        exibirResultadosBusca(users, "VULNERÁVEL");
    }
    
    private void buscarUsuarioSeguro() {
        System.out.print("Digite o usuário: ");
        String usuario = scanner.nextLine();
        
        List<User> users = userService.getUserSecure(usuario);
        exibirResultadosBusca(users, "SEGURO");
    }
    
    private void exibirResultadosBusca(List<User> users, String tipo) {
        System.out.println("\n=== RESULTADO DA BUSCA (" + tipo + ") ===");
        
        if (users.isEmpty()) {
            System.out.println("❌ Nenhum usuário encontrado!");
        } else {
            System.out.println("✅ " + users.size() + " usuário(s) encontrado(s):");
            for (User user : users) {
                System.out.println("Usuário: " + user.getUsuario() + 
                                 " | Senha: " + user.getSenha());
            }
        }
    }
    
    private void atualizarUsuario() {
        System.out.print("Usuário para atualizar: ");
        String usuario = scanner.nextLine();
        System.out.print("Nova senha: ");
        String novaSenha = scanner.nextLine();
        
        User user = new User(usuario, novaSenha);
        
        if (userService.updateUser(user)) {
            System.out.println("✅ Senha atualizada com sucesso!");
        } else {
            System.out.println("❌ Erro ao atualizar senha!");
        }
    }
    
    private void deletarUsuario() {
        System.out.print("Usuário para deletar: ");
        String usuario = scanner.nextLine();
        
        if (userService.deleteUser(usuario)) {
            System.out.println("✅ Usuário deletado com sucesso!");
        } else {
            System.out.println("❌ Erro ao deletar usuário!");
        }
    }
    
    private void testarSQLInjection() {
        System.out.println("\n=== TESTE DE SQL INJECTION ===");
        System.out.println("Exemplos de inputs para testar:");
        System.out.println("1. ' OR '1'='1 - Retorna todos os usuários");
        System.out.println("2. admin' -- - Bypassa autenticação");
        System.out.println("3. x'; DROP TABLE users; -- - ⚠️ PERIGOSO!");
        
        System.out.print("\nDigite o input para teste: ");
        String input = scanner.nextLine();
        
        System.out.println("\n--- MÉTODO VULNERÁVEL ---");
        List<User> usersVulnerable = userService.getUserVulnerable(input);
        exibirResultadosBusca(usersVulnerable, "VULNERÁVEL");
        
        System.out.println("\n--- MÉTODO SEGURO ---");
        List<User> usersSecure = userService.getUserSecure(input);
        exibirResultadosBusca(usersSecure, "SEGURO");
    }
}