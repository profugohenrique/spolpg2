package service;

import dao.UserDAO;
import model.User;
import java.util.List;

public class UserService {
    private UserDAO userDAO;
    
    public UserService() {
        this.userDAO = new UserDAO();
    }
    
    public boolean addUser(User user) {
        return userDAO.addUser(user);
    }
    
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
    
    public List<User> getUserVulnerable(String usuario) {
        return userDAO.getUserVulnerable(usuario);
    }
    
    public List<User> getUserSecure(String usuario) {
        return userDAO.getUserSecure(usuario);
    }
    
    public boolean updateUser(User user) {
        return userDAO.updateUser(user);
    }
    
    public boolean deleteUser(String usuario) {
        return userDAO.deleteUser(usuario);
    }
}