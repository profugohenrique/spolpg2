package view;

import controller.UserController;

public class MainView {
    public static void main(String[] args) {
        UserController controller = new UserController();
        controller.iniciar();
    }
}