/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.ifsp.Exemplo1.controller;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DadosController {

    @GetMapping("/")
    public String mostrarFormulario() {
        return "formulario";
    }

    @PostMapping("/processar")
    public String processarDados(
        @RequestParam("parametroPost") String parametroPost,
        @RequestParam("parametroGet") String parametroGet,
        HttpServletRequest request,
        Model model) {
    
    model.addAttribute("parametroPost", parametroPost);
    model.addAttribute("parametroGet", parametroGet);
    model.addAttribute("metodoHttp", request.getMethod());
    
    return "resultado";
}
    @GetMapping("/dados")
    public String mostrarDadosComGet(
            @RequestParam("parametroGet") String parametroGet,
            Model model) {
        
        model.addAttribute("parametroGet", parametroGet);
        model.addAttribute("parametroPost", "Não informado via POST");
        
        return "resultado";
    }
}